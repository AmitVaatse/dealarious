<?php
/**
 * Template name: Home Page Template 
 * The template for displaying about pages.
 */
get_header('shop');
?>
<div class="contents">
	<div class="homepage">
		<div class="top_banner">
			<h1>Happy New Year</h1>
			<p>Lorem lepsum m here asshole eu feugiat nulla facilisis at vero eros et accumsan</p>
		</div>
		<div class="deal_shc">
			<div class="hdr">
						<div class="hd1" id="hda">DEALS OF THE DAY</div>
						<div class="hd1" id="hdb">TOP SELLER</div>
						<div class="hd1" id="hdc">Featured Products</div>
			</div>
			<div class="contents" id="hda1" style="display: block">
					<div class="product" style="margin-top:20px;">
			    <?php
			        $args = array( 'post_type' => 'product', 'posts_per_page' => 1 );
			        $loop = new WP_Query( $args );
			        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
			         <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
			            <div class="prod_image">
			            	<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?></div></a>
						<div class="prod_spec">
							<h1 class="margin_zero black"><?php the_title(); ?></h1>
							<p class="margin_zero red"style="text-align:left;">m here asshole eu feugiat nulla facilisis at vero eros et accumsan</p>
							<h3 class="margin_top black">DESCRIPTION</h3>
							<p class="margin_zero grey"style="text-align:left;"><?php echo $post->post_excerpt; ?></p>
							<div class="off"><img src="<?php bloginfo('template_url'); ?>/images/dod.png"></div>
							<h4 class="margin_zero black"style="text-align:left;">RATING: <?php ?></h4>
							<h4 class="margin_top red">MRP: <?php echo $product->get_price_html();$after_widget?></h4>
							<h3 class="margin_top red">Our Price : <?php echo $product->price; ?>	</h3>
							<h1 class="margin_top green"><?php echo $product->stock_status ?></h1>
							<p class="margin_zero black"style="text-align:left;">Standard delivery in 2-3 business days.[?]</p>
							<h5 class="margin_bottom black"style="text-align:left;">Note: In-a-day Guarantee orders placed before 6PM will be delivered on the next</br> 
			business day. Orders after 6PM will be delivered the day after.</h5>
							<div class="buy"><img src="<?php bloginfo('template_url'); ?>/images/buy.png"></div>
							<div class="dwn"><img src="<?php bloginfo('template_url'); ?>/images/dwn.png"></div>
						</div>

			    <?php endwhile; ?>
			    <?php wp_reset_query(); ?>
			    <div class="bubble">
		           <div class="inside">
		             <div class="inside-text">
		             	<?php 
					$percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
					echo $price . sprintf( __('%s', 'woocommerce' ), $percentage . '%' ); ?></div>
		           </div>
	    		</div>
			</div>
		</div>
		<div class="contents" id="hda2" style="display:none;">
					<div class="product"style="margin-top:20px;">
			    <?php
			        $args = array( 'post_type' => 'product', 'posts_per_page' => 1 );
			        $loop = new WP_Query( $args );
			        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
			         <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
			            <div class="prod_image"><?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?></div></a>
						<div class="prod_spec">
							<h1 class="margin_zero black"><?php the_title(); ?></h1>
							<p class="margin_zero red">m here asshole eu feugiat nulla facilisis at vero eros et accumsan</p>
							<h3 class="margin_top black">DESCRIPTION</h3>
							<p class="margin_zero grey"><?php echo $post->post_excerpt; ?></p>
							<div class="off"></div>
							<h4 class="margin_zero black">RATING: <?php echo $product->get_rating_html();?></h4>
							<h4 class="margin_top red">MRP: <?php echo $product->get_price_html();$after_widget?></h4>
							<h3 class="margin_top red">Our Price : <?php echo $product->price; ?>	</h3>
							<h1 class="margin_top green"><?php echo $product->stock_status ?></h1>
							<p class="margin_zero black">Standard delivery in 2-3 business days.[?]</p>
							<h5 class="margin_bottom black">Note: In-a-day Guarantee orders placed before 6PM will be delivered on the next</br> 
			business day. Orders after 6PM will be delivered the day after.</h5>
							<div class="buy"><img src="<?php bloginfo('template_url'); ?>/images/buy.png"></div>
							<div class="dwn"><img src="<?php bloginfo('template_url'); ?>/images/dwn.png"></div>
						</div>

			    <?php endwhile; ?>
			    <?php wp_reset_query(); ?>
			    <div class="bubble">
		           <div class="inside">
		             <div class="inside-text">
		             	<?php 
					$percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
					echo $price . sprintf( __('%s', 'woocommerce' ), $percentage . '%' ); ?></div>
		           </div>
	    		</div>
			</div>
		</div>
				<div class="contents" id="hda3" style="display:none;">
					<div class="product"style="margin-top:20px;">
			    <?php
			        $args = array( 'post_type' => 'product', 'posts_per_page' => 1 );
			        $loop = new WP_Query( $args );
			        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
			         <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
			            <div class="prod_image"><?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?></div></a>
						<div class="prod_spec">
							<h1 class="margin_zero black"><?php the_title(); ?></h1>
							<p class="margin_zero red">m here asshole eu feugiat nulla facilisis at vero eros et accumsan</p>
							<h3 class="margin_top black">DESCRIPTION</h3>
							<p class="margin_zero grey"><?php echo $post->post_excerpt; ?></p>
							<div class="off"></div>
							<h4 class="margin_zero black">RATING: <?php echo $product->get_rating_html();?></h4>
							<h4 class="margin_top red">MRP: <?php echo $product->get_price_html();$after_widget?></h4>
							<h3 class="margin_top red">Our Price : <?php echo $product->price; ?>	</h3>
							<h1 class="margin_top green"><?php echo $product->stock_status ?></h1>
							<p class="margin_zero black">Standard delivery in 2-3 business days.[?]</p>
							<h5 class="margin_bottom black">Note: In-a-day Guarantee orders placed before 6PM will be delivered on the next</br> 
			business day. Orders after 6PM will be delivered the day after.</h5>
							<div class="buy"><img src="<?php bloginfo('template_url'); ?>/images/buy.png"></div>
							<div class="dwn"><img src="<?php bloginfo('template_url'); ?>/images/dwn.png"></div>
						</div>

			    <?php endwhile; ?>
			    <?php wp_reset_query(); ?>
			    <div class="bubble">
		           <div class="inside">
		             <div class="inside-text">
		             	<?php 
					$percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
					echo $price . sprintf( __('%s', 'woocommerce' ), $percentage . '%' ); ?></div>
		           </div>
	    		</div>
			</div>
				</div>
		</div>



		<!--category starts from here -->			
			<div class="prod_cat_container">
				<div class="prod_cat_navigation">					
					<div class="name_product">
					<h3>Antivirus</h3>						
					</div>
					<ul>
					 	<?php wp_list_categories( 'taxonomy=product_cat&pad_counts=1&title_li=' ); ?>
					</ul>
				</div>
				 <?php
        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => 'antivir', 'orderby' => 'rand' );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
				<div class="prod_cat_collection">
					 <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">

					<div class="products_simple">
						 <?php woocommerce_show_product_sale_flash( $post, $product ); ?>
						<h2><?php the_title(); ?></h2>
						<h4 style="text-decoration:none;">Extra <?php 
					$percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
					echo $price . sprintf( __('%s', 'woocommerce' ), $percentage . '%' ); ?> Saving</h4>
						 <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						<div class="snipit">
					         <h4><?php the_title(); ?></h4>
					         <h4>USE Coupon:<b style="color:#e9c205">GV73FDSF</b></h4>
					         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
					         <h4 class="margin_top red">MRP: <?php echo $product->regular_price ?></h4>
                			 <h4 class="margin_top red">Our Price : <?php echo $product->price; ?> </h4>				         
					    	 <?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
					    </div>
					</div>
					</a>
					<?php endwhile; ?>
    <?php wp_reset_query(); ?>					
				</div>
			</div>
			<div class="prod_cat_container">
				<div class="prod_cat_navigation">					
					<div class="name_product">
						<h3>Security Utility</h3>
					</div>
					<ul>
					 	<?php wp_list_categories( 'taxonomy=product_cat&pad_counts=1&title_li=' ); ?>
					</ul>
				</div>
				 <?php
        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => 'sec', 'orderby' => 'rand' );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
				<div class="prod_cat_collection">
					 <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">

					<div class="products_simple">
						 <?php woocommerce_show_product_sale_flash( $post, $product ); ?>
						<h2><?php the_title(); ?></h2>
						<h4 style="text-decoration:none;">Extra <?php 
					$percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
					echo $price . sprintf( __('%s', 'woocommerce' ), $percentage . '%' ); ?> Saving</h4>
						 <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						<div class="snipit">
					         <h4><?php the_title(); ?></h4>
					         <h4>USE Coupon:<b style="color:#e9c205">GV73FDSF</b></h4>
					         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
					         <h4 class="margin_top red">MRP: <?php echo $product->regular_price ?></h4>
                			 <h4 class="margin_top red">Our Price : <?php echo $product->price; ?> </h4>				         
					    	 <?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
					    </div>
					</div>
					</a>
					<?php endwhile; ?>
    <?php wp_reset_query(); ?>					
				</div>
			</div>
	</div>	
</div>
<?php get_footer();?>