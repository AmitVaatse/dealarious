<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * Override this template by copying it to yourtheme/woocommerce/content-single-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<div class="content">
       <div class="product">
            <div class="prod_image">
               <div id="bigpic" class="b">
            <img src="http://www.web-design-talk.co.uk/examples/5/images/big/iphone-3-big.jpg" alt="iPod Shuffle 16GB Zoom View" />
           
        </div>
        <div id="thumbs">
            <ul>
                <li><a href="http://www.web-design-talk.co.uk/examples/5/images/big/iphone-1-big.jpg" rel="http://www.web-design-talk.co.uk/examples/5/images/small/iphone-1-small.jpg">
                        <img src="http://www.web-design-talk.co.uk/examples/5/images/small/iphone-1-small.jpg" alt="iPod Shuffle Front View In Blue!" />
                    </a>
                </li>

                <li>
                    <a href="http://www.web-design-talk.co.uk/examples/5/images/big/iphone-2-big.jpg" rel="http://www.web-design-talk.co.uk/examples/5/images/small/iphone-2-small.jpg">
                        <img src="http://www.web-design-talk.co.uk/examples/5/images/small/iphone-2-small.jpg" alt="iPod Shuffle Dual View Grey!" />
                    </a>
                </li
                >
                <li>
                    <a href="http://www.web-design-talk.co.uk/examples/5/images/big/iphone-3-big.jpg" rel="http://www.web-design-talk.co.uk/examples/5/images/small/iphone-3-small.jpg">
                        <img src="http://www.web-design-talk.co.uk/examples/5/images/small/iphone-3-small.jpg" alt="iPod Shuffle 16GB Zoom View" />
                    </a>
                </li>
            </ul>

        </div>
            </div>
            <div class="prod_spec">
                <h1 class="margin_zero black"><?php the_title();?></h1>
                <p class="margin_zero red"style="text-align:left;">dolore eu feugiat nulla facilisis at vero eros et accumsan</p>
                <h3 class="margin_top black">DESCRIPTION</h3>
                <p class="margin_zero grey"style="text-align:left;"><?php echo $post->post_excerpt; ?></p>
                <div class="off"></div>
                <h4 class="margin_zero black"style="text-align:left;">RATING:<?php ?></h4>
                <h4 class="margin_top red">MRP: <?php echo $product->regular_price ?></h4>
                <h3 class="margin_top red">Our Price : <?php echo $product->price; ?> </h3>
                <h1 class="margin_top green"> In stock</h1>
                <p class="margin_zero black"style="text-align:left;">Standard delivery in 2-3 business days.[?]</p>
                <h5 class="margin_bottom black"style="text-align:left;">Note: In-a-day Guarantee orders placed before 6PM will be delivered on the next</br> 
business day. Orders after 6PM will be delivered the day after.</h5>
<div class="buy"><img src="<?php bloginfo('template_url')?>/images/buy.png"></div>
    
                <div class="dwn"><img src="<?php bloginfo('template_url')?>/images/dwn.png"></div>
            </div>            
        </div>
        <div class="slider_product">
            <div id="ca-container" class="ca-container">
                <div class="ca-wrapper">
                    <div class="ca-item ca-item-1">
                        <div class="ca-item-main">
                            <div class="ca-icon"></div>
                            <h3>Stop factory farming</h3>
                            <h4>
                                <span class="ca-quote">&ldquo;</span>
                                <span>The greatness of a nation and its moral progress can be judged by the way in which its animals are treated.</span>
                            </h4>
                                <a href="#" class="ca-more">more...</a>
                        </div>
                        <div class="ca-content-wrapper">
                            <div class="ca-content">
                                <h6>Animals are not commodities</h6>
                                <a href="#" class="ca-close">close</a>
                                <div class="ca-content-text">
                                    <p>I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents. I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.</p>
                                    <p>When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream;</p>
                                    <p>She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
                                </div>
                                <ul>
                                    <li><a href="#">Read more</a></li>
                                    <li><a href="#">Share this</a></li>
                                    <li><a href="#">Become a member</a></li>
                                    <li><a href="#">Donate</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="ca-item ca-item-2">
                        <div class="ca-item-main">
                            <div class="ca-icon"></div>
                            <h3>Respect Life &amp; Rights</h3>
                            <h4>
                                <span class="ca-quote">&ldquo;</span>
                                <span>I hold that the more helpless a creature, the more entitled it is to protection by man from the cruelty of man.</span>
                            </h4>
                                <a href="#" class="ca-more">more...</a>
                        </div>
                        <div class="ca-content-wrapper">
                            <div class="ca-content">
                                <h6>Would you eat your dog?</h6>
                                <a href="#" class="ca-close">close</a>
                                <div class="ca-content-text">
                                    <p>I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents. I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.</p>
                                    <p>When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream;</p>
                                    <p>She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
                                </div>
                                <ul>
                                    <li><a href="#">Read more</a></li>
                                    <li><a href="#">Share this</a></li>
                                    <li><a href="#">Become a member</a></li>
                                    <li><a href="#">Donate</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="ca-item ca-item-3">
                        <div class="ca-item-main">
                            <div class="ca-icon"></div>
                            <h3>Become 100% meat-free</h3>
                            <h4>
                                <span class="ca-quote">&ldquo;</span>
                                <span>I feel that spiritual progress does demand at some stage that we should cease to kill our fellow creatures for the satisfaction of our bodily wants.</span>
                            </h4>
                                <a href="#" class="ca-more">more...</a>
                        </div>
                        <div class="ca-content-wrapper">
                            <div class="ca-content">
                                <h6>You can change the world</h6>
                                <a href="#" class="ca-close">close</a>
                                <div class="ca-content-text">
                                    <p>I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents. I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.</p>
                                    <p>When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream;</p>
                                    <p>She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
                                </div>
                                <ul>
                                    <li><a href="#">Read more</a></li>
                                    <li><a href="#">Share this</a></li>
                                    <li><a href="#">Become a member</a></li>
                                    <li><a href="#">Donate</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="ca-item ca-item-4">
                        <div class="ca-item-main">
                            <div class="ca-icon"></div>
                            <h3>Make a difference</h3>
                            <h4>
                                <span class="ca-quote">&ldquo;</span>
                                <span>A man is but the product of his thoughts what he thinks, he becomes.</span>
                            </h4>
                                <a href="#" class="ca-more">more...</a>
                        </div>
                        <div class="ca-content-wrapper">
                            <div class="ca-content">
                                <h6>Think globally, act locally</h6>
                                <a href="#" class="ca-close">close</a>
                                <div class="ca-content-text">
                                    <p>I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents. I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.</p>
                                    <p>When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream;</p>
                                    <p>She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
                                </div>
                                <ul>
                                    <li><a href="#">Read more</a></li>
                                    <li><a href="#">Share this</a></li>
                                    <li><a href="#">Become a member</a></li>
                                    <li><a href="#">Donate</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="ca-item ca-item-5">
                        <div class="ca-item-main">
                            <div class="ca-icon"></div>
                            <h3>Say no to killing</h3>
                            <h4>
                                <span class="ca-quote">&ldquo;</span>
                                <span>A weak man is just by accident. A strong but non-violent man is unjust by accident.</span>
                            </h4>
                                <a href="#" class="ca-more">more...</a>
                        </div>
                        <div class="ca-content-wrapper">
                            <div class="ca-content">
                                <h6>Animals have rights, too!</h6>
                                <a href="#" class="ca-close">close</a>
                                <div class="ca-content-text">
                                    <p>I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents. I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.</p>
                                    <p>When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream;</p>
                                    <p>She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
                                </div>
                                <ul>
                                    <li><a href="#">Read more</a></li>
                                    <li><a href="#">Share this</a></li>
                                    <li><a href="#">Become a member</a></li>
                                    <li><a href="#">Donate</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="ca-item ca-item-6">
                        <div class="ca-item-main">
                            <div class="ca-icon"></div>
                            <h3>Don't believe the lies</h3>
                            <h4>
                                <span class="ca-quote">&ldquo;</span>
                                <span>An error does not become truth by reason of multiplied propagation, nor does truth become error because nobody sees it.</span>
                            </h4>
                                <a href="#" class="ca-more">more...</a>
                        </div>
                        <div class="ca-content-wrapper">
                            <div class="ca-content">
                                <h6>How essential is meat?</h6>
                                <a href="#" class="ca-close">close</a>
                                <div class="ca-content-text">
                                    <p>I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents. I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.</p>
                                    <p>When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream;</p>
                                    <p>She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
                                </div>
                                <ul>
                                    <li><a href="#">Read more</a></li>
                                    <li><a href="#">Share this</a></li>
                                    <li><a href="#">Become a member</a></li>
                                    <li><a href="#">Donate</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="ca-item ca-item-7">
                        <div class="ca-item-main">
                            <div class="ca-icon"></div>
                            <h3>Save the planet</h3>
                            <h4>
                                <span class="ca-quote">&ldquo;</span>
                                <span>A small body of determined spirits fired by an unquenchable faith in their mission can alter the course of history.</span>
                            </h4>
                                <a href="#" class="ca-more">more...</a>
                        </div>
                        <div class="ca-content-wrapper">
                            <div class="ca-content">
                                <h6>Collateral damage?</h6>
                                <a href="#" class="ca-close">close</a>
                                <div class="ca-content-text">
                                    <p>I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents. I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.</p>
                                    <p>When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream;</p>
                                    <p>She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
                                </div>
                                <ul>
                                    <li><a href="#">Read more</a></li>
                                    <li><a href="#">Share this</a></li>
                                    <li><a href="#">Become a member</a></li>
                                    <li><a href="#">Donate</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="ca-item ca-item-8">
                        <div class="ca-item-main">
                            <div class="ca-icon"></div>
                            <h3>It's time to move on</h3>
                            <h4>
                                <span class="ca-quote">&ldquo;</span>
                                <span>A nation's culture resides in the hearts and in the soul of its people.</span>
                            </h4>
                                <a href="#" class="ca-more">more...</a>
                        </div>
                        <div class="ca-content-wrapper">
                            <div class="ca-content">
                                <h6>Let's finally become humans</h6>
                                <a href="#" class="ca-close">close</a>
                                <div class="ca-content-text">
                                    <p>I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents. I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.</p>
                                    <p>When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream;</p>
                                    <p>She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
                                </div>
                                <ul>
                                    <li><a href="#">Read more</a></li>
                                    <li><a href="#">Share this</a></li>
                                    <li><a href="#">Become a member</a></li>
                                    <li><a href="#">Donate</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="product_desc">
            <div class="short_desc">
                <h2>SHORT DESCRIPTION</h2>
                <p style="text-align:justify;"><?php echo apply_filters( 'woocommerce_short_description', $post->post_excerpt ) ?></p>
            </div>
            <?php echo apply_filters( 'woocommerce_variation_option_name', $term->name )?>
            <div class="tech_desc">

                <h2 class="margin_top black">TECH SPECS</h2>
                <h4 class="margin_top black">SIZE</h4>
                <h4 class="margin_top black">COMPATIBILITY</h4>
                <h4 class="margin_top black">VERSION</h4>
                <h4 class="margin_top black">DEVELOPER</h4>
                <h4 class="margin_top black">LICENSE</h4>
            </div>
        </div>
        <div class="customer_rev">
            <h2 class="margin_zero">CUSTOMER REVIEW</h2>
            <div class="cus_des">
                
                <?php
				    $args = array ('post_type' => 'product');
				    $comments = get_comments( $args );
				    wp_list_comments('type=comment&callback=mytheme_comment', $comments);
				?>
            </div>      
            <div class="related">
                <div class="prod_s">
                    <h3 class="margin-left margin_top"style="color:#694338;"></h3>
                   <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Home right sidebar')) :
					endif; ?>
                </div>
            </div>  
            <div class="news">
                <div class="news_s">
                    <h3 class="margin-left margin_top"style="color:#032a40;">NEWSLETTER</h3>
                </div>
            </div>
        </div>
     </div><!-- #product-<?php the_ID(); ?> -->

<?php do_action( 'woocommerce_after_single_product' ); ?>